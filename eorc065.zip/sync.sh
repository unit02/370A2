cp sync.py sync
chmod +x sync
./sync dir1 dir2
